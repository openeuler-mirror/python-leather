import leather

data1 = [
    (0, 3),
    (4, 5),
    (7, 9),
    (8, 4)
]

data2 = [
    (3, 4),
    (5, 6),
    (7, 10),
    (8, 2)
]

chart1 = leather.Chart('Dots')
chart1.add_dots(data1)

chart2 = leather.Chart('Lines')
chart2.add_line(data2)

grid = leather.Grid()
grid.add_one(chart1)
grid.add_one(chart2)
grid.to_svg('examples/charts/grid.svg')
