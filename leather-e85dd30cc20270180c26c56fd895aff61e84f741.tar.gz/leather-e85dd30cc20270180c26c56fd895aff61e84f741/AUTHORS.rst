The following individuals have contributed code, documentation, or expertise to leather:

* `Christopher Groskopf <https://github.com/onyxfish/>`_
