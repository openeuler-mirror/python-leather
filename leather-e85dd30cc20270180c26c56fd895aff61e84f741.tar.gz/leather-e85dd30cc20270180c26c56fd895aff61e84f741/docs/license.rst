=======
License
=======

.. include:: ../COPYING
