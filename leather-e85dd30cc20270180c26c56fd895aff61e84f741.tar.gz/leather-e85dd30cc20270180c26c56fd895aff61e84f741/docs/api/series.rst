======
Series
======

.. automodule:: leather.series
    :no-members:

.. autoclass:: leather.Series

.. autofunction:: leather.key_function
