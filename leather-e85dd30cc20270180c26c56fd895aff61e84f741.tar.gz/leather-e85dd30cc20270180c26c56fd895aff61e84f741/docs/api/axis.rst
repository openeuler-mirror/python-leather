====
Axis
====

.. automodule:: leather.axis
    :no-members:

.. autoclass:: leather.Axis
